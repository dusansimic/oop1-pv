interface Servis {
    boolean popravi();
}
